<?php 

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once 'vendor/autoload.php';
// echo "uttam";

// exit();
//Create the Transport
// $transport = (new Swift_SmtpTransport('smtp.googlemail.com', 465, 'ssl'))
//   ->setUsername('uttamvishwakarma99@gmail.com')
//   ->setPassword('rieambeilyevsqbx')
;

$transport = (new Swift_SmtpTransport('smtp.googlemail.com', 465, 'ssl'))
  ->setUsername('info@positivequadrant.in')
  ->setPassword('tcneycpnflqcapxv')
;

// Create the Mailer using your created Transport
$mailer = new Swift_Mailer($transport);

$html = "<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>

<b>Hi Uttam Vishwakarma</b>
<p>Dear <b>Uttam</b><p>,

<p>We trust this message finds you in good health and high spirits.</p>

<p>We are delighted to inform you that you have successfully attended the two-day online webinar on [topic/title of the webinar] organized by [Organizing Institution/Company]. Your participation and engagement greatly contributed to the success of the event.</p>

<p>Enclosed, please find your Certificate of Attendance, which serves as a testament to your commitment to continuous learning and professional development. We hope that the knowledge gained during this webinar will prove valuable in your academic and professional pursuits.</p>

<p>We would like to express our sincere appreciation for your active participation. Your presence was instrumental in making this event a meaningful and enriching experience for all involved.</p>

<p>Should you have any questions or require further assistance, please feel free to reach out.</p>

<p>Once again, congratulations on your successful completion of the webinar. We look forward to your continued engagement in future events and initiatives.</p>

Warm regards,</p>


<h1>Positive Quadrant Technologies LLP</h1>
</body>
</html>";
// Create a message
$message = (new Swift_Message(' Certificate of Achievement Uttam Vishwakarma'))
  ->setFrom(['uttamvishwakarma99@gmail.com' => 'Positive Quadrant Technologies'])
  ->setTo(['uttamvishwakarma99@gmail.com','uvcoderepo@gmail.com'])
  ->setBody($html, 'text/html')
  ;

// Send the message
// $result = $mailer->send($message);

  try {
        $mailer->send($message);
    }
    catch (\Swift_TransportException $e) {
        echo $e->getMessage();
    }


?>